import React from "react";

export default function Counter(props) {
  return (
    <div>
      <h1>{props.name}</h1>
      <button onClick={() => props.increment(5)}>+5</button>
      <button onClick={() => props.increment(10)}>+10</button>
      <button onClick={() => props.decrement(5)}>-5</button>
      <button onClick={() => props.decrement(10)}>-10</button>
    </div>
  );
}

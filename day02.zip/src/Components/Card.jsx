import React from "react";

export default function Card(props) {
  let number = 7;
  return (
    <div>
      <h3>{props.name}</h3>
      <button onClick={() => props.getData(number)}>Click Me</button>
    </div>
  );
}

import React, { useState } from "react";

export default function FullRevisionCard() {
  const [data, setData] = useState([
    { name: "HTML", vote: 2 },
    { name: "CSS", vote: 1 },
    { name: "JavaScript", vote: 4 },
  ]);
  let inputValue = "";
  return (
    <div>
      {data.map((object, index) => (
        <div className="card" key={index}>
          <h1>{object.name}</h1>
          <h3>{object.vote}</h3>
          <button
            onClick={() =>
              setData((prevValue) => {
                let copyData = [...prevValue];
                copyData[index].vote += 1;
                return copyData;
              })
            }
          >
            +
          </button>
          <button
            onClick={() =>
              setData((prevValue) => {
                let copyData = [...prevValue];
                copyData[index].vote -= 1;
                return copyData;
              })
            }
          >
            -
          </button>
        </div>
      ))}
      <input
        type="text"
        placeholder="title"
        onChange={(event) => {
          inputValue = event.target.value;
        }}
      />
      <button
        onClick={() => {
          setData((prevValue) => [...prevValue, { name: inputValue, vote: 0 }]);
        }}
      >
        Add Item
      </button>
    </div>
  );
}

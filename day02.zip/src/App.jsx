import "./App.css";
import Card from "./Components/Card";
import Counter from "./Components/Counter";
import { useState } from "react";
import FullRevisionCard from "./Components/FullRevisionCard";

function App() {
  // const names = ["Alex", "Anson", "Asis", "Chloe", "Chris", "Bibek"];
  // let num = 0;
  // const [count, setCount] = useState(0);
  // function increment(num) {
  //   setCount(count + num);
  // }

  // function decrement(num) {
  //   if (count > 0) {
  //     setCount(count - num);
  //   }
  // }
  return (
    <div className="App">
      <FullRevisionCard />
      {/* {names.map((name, index) => (
        <Card
          key={index}
          name={name}
          getData={(data) => {
            num = data;
            console.log("This is the data", data);
          }}
        />
      ))} */}
      {/* <h1>{count}</h1>
      <Counter name="Counter" increment={increment} decrement={decrement} /> */}
    </div>
  );
}

export default App;

import "./App.css";
import FullRevisionCard from "./Components/FullRevisionCard";

function App() {
  return (
    <div className="App">
      <FullRevisionCard />
    </div>
  );
}

export default App;
